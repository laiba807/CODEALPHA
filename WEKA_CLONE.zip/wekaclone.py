import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
import seaborn as sns
import matplotlib.pyplot as plt

class WekaCloneApp:
    def __init__(self, master):
        self.master = master
        master.title("WEKA CLONE")
        master.geometry("500x400")

        self.canvas = tk.Canvas(master, width=500, height=400)
        self.canvas.pack()

        # Create a label with the header
        self.header_label = tk.Label(master, text="WEKA CLONE", font=("Helvetica", 16, "bold"), fg="white", bg="#007bff")
        self.header_label.place(relx=0.5, rely=0.05, anchor=tk.N)

        # Create a silver to turquoise gradient background
        for i in range(400):
            self.canvas.create_rectangle(0, i, 500, i + 1, fill='#C0C0C0', outline='')
            self.canvas.create_rectangle(0, 400 - i, 500, 400 - i - 1, fill='#40E0D0', outline='')

        # Create a label with a welcome message
        self.welcome_label = tk.Label(master, text="Welcome to WEKA CLONE!", font=("Helvetica", 14))
        self.welcome_label.place(relx=0.5, rely=0.15, anchor=tk.CENTER)

        # Create a button to upload the dataset
        self.upload_button = tk.Button(master, text="Upload your Dataset", command=self.upload_dataset, bg="#007bff", fg="white", font=("Helvetica", 12))
        self.upload_button.place(relx=0.5, rely=0.25, anchor=tk.CENTER)

    def upload_dataset(self):
        
        file_path = filedialog.askopenfilename()
        # Check if a file is selected
        if file_path:
            print("Dataset uploaded from:", file_path)
            # Load the dataset
            data = pd.read_csv(file_path)
            # Check if there are missing values or errors
            if data.isnull().values.any():
                # Handling missing values by dropping rows
                data.dropna(inplace=True)
                # Save the preprocessed dataset
                preprocessed_filepath = file_path.replace('.csv', '_preprocessed.csv')
                data.to_csv(preprocessed_filepath, index=False)
                print("Data preprocessing is Done and saved to:", preprocessed_filepath)
                self.show_preprocessing_details(file_path, preprocessed_filepath, data)
            else:
                print("Dataset is already Preprocessed")
                self.already_preprocessing_details(file_path, data)
            # After dataset upload, select algorithm
            self.select_algorithm(data)
            
    def already_preprocessing_details(self, file_path, data):
        
        preprocessing_window = tk.Toplevel(self.master)
        preprocessing_window.title("Preprocessing Details")
        preprocessing_window.geometry("400x200")

        preprocessing_frame = tk.Frame(preprocessing_window, bg="#E8E8E8")
        preprocessing_frame.place(relwidth=1, relheight=1)

        preprocessing_label = tk.Label(preprocessing_frame, text="Data Preprocessing Details", font=("Helvetica", 20, "bold"), bg="#E8E8E8")
        preprocessing_label.place(relx=0.5, rely=0.1, anchor=tk.N)
        
        file_label = tk.Label(preprocessing_frame, text=f"Dataset uploaded from: {file_path}\nDataset is already preprocessed", font=("Helvetica", 12), bg="#E8E8E8")
        file_label.place(relx=0.5, rely=0.3, anchor=tk.N)

        close_button = tk.Button(preprocessing_frame, text="Close", command=preprocessing_window.destroy, bg="#007bff", fg="white")
        close_button.place(relx=0.5, rely=0.8, anchor=tk.CENTER)

    def show_preprocessing_details(self, file_path, preprocessed_filepath, data):
     
        preprocessing_window = tk.Toplevel(self.master)
        preprocessing_window.title("Preprocessing Details")
        preprocessing_window.geometry("400x200")

        preprocessing_frame = tk.Frame(preprocessing_window, bg="#E8E8E8")
        preprocessing_frame.place(relwidth=1, relheight=1)

        preprocessing_label = tk.Label(preprocessing_frame, text="Data Preprocessing Details", font=("Helvetica", 14, "bold"), bg="#E8E8E8")
        preprocessing_label.place(relx=0.5, rely=0.1, anchor=tk.N)

        file_label = tk.Label(preprocessing_frame, text=f"Dataset uploaded from: {file_path}\nPreprocessed File Saved at: {preprocessed_filepath}", font=("Helvetica", 12), bg="#E8E8E8")
        file_label.place(relx=0.5, rely=0.3, anchor=tk.N)

        close_button = tk.Button(preprocessing_frame, text="Close", command=preprocessing_window.destroy, bg="#007bff", fg="white")
        close_button.place(relx=0.5, rely=0.8, anchor=tk.CENTER)

    def run_algorithm(self, dataset, algorithm, target):
        """
        Function to run selected algorithm on dataset
        """
        features = [col for col in dataset.columns if col != target]

        if algorithm == "Naive Bayes":
            try:
                model = GaussianNB()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("Naive Bayes algorithm executed successfully.")
                self.show_results(y_test, y_pred, model, X_test)
            except ValueError:
                print("Naive Bayes does not support the dataset.")
        elif algorithm == "Logistic Regression":
            try:
                model = LogisticRegression()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("Logistic Regression algorithm executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, logistic=True)
            except ValueError:
                print("Logistic Regression does not support the dataset.")
        elif algorithm == "Decision Tree (J48)":
            try:
                model = DecisionTreeClassifier()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("Decision Tree algorithm (J48) executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, tree=True)
            except ValueError:
                print("Decision Tree does not support the dataset.")
        elif algorithm == "K-Nearest Neighbors (KNN)":
            try:
                model = KNeighborsClassifier()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("K-Nearest Neighbors (KNN) algorithm executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, knn=True)
            except ValueError:
                print("K-Nearest Neighbors (KNN) does not support the dataset.")

    def show_results(self, y_test, y_pred, model, X_test, logistic=False, tree=False, knn=False, naive_bayes=False):
        """
        Show results of the classification
        """
        print("Confusion Matrix:")
        print(confusion_matrix(y_test, y_pred))
        print("Classification Report:")
        print(classification_report(y_test, y_pred))
        print("Accuracy Score:", accuracy_score(y_test, y_pred))

        # Create a new window for results
        result_window = tk.Toplevel(self.master)
        result_window.title("Algorithm Results")
        result_window.geometry("500x500")

        result_frame = tk.Frame(result_window, bg="#E8E8E8")
        result_frame.place(relwidth=1, relheight=1)

        result_label = tk.Label(result_frame, text=f"Results - {model.__class__.__name__}", font=("Helvetica", 14, "bold"), bg="#E8E8E8")
        result_label.place(relx=0.5, rely=0.05, anchor=tk.N)

        accuracy_label = tk.Label(result_frame, text=f"Accuracy Score: {accuracy_score(y_test, y_pred)}", font=("Helvetica", 12), bg="#E8E8E8")
        accuracy_label.place(relx=0.5, rely=0.15, anchor=tk.N)

        # Button to show confusion matrix
        confusion_button = tk.Button(result_frame, text="Confusion Matrix", command=lambda: self.show_confusion_matrix(y_test, y_pred), bg="#007bff", fg="white", font=("Helvetica", 12))
        confusion_button.place(relx=0.5, rely=0.25, anchor=tk.N)

        # Button to show classification report
        classification_button = tk.Button(result_frame, text="Classification Report", command=lambda: self.show_classification_report(y_test, y_pred), bg="#007bff", fg="white", font=("Helvetica", 12))
        classification_button.place(relx=0.5, rely=0.35, anchor=tk.N)

        if logistic:
            # Button to show feature importance plot
            feature_button = tk.Button(result_frame, text="Feature Importance Plot", command=lambda: self.show_feature_importance(model, X_test), bg="#007bff", fg="white", font=("Helvetica", 12))
            feature_button.place(relx=0.5, rely=0.45, anchor=tk.N)
        elif tree:
            # Button to show decision tree
            tree_button = tk.Button(result_frame, text="Decision Tree", command=lambda: self.show_decision_tree(model, X_test), bg="#007bff", fg="white", font=("Helvetica", 12))
            tree_button.place(relx=0.5, rely=0.45, anchor=tk.N)
        elif knn:
            # Button to show scatter plot
            scatter_button = tk.Button(result_frame, text="Scatter Plot", command=lambda: self.show_scatter_plot(model, X_test), bg="#007bff", fg="white", font=("Helvetica", 12))
            scatter_button.place(relx=0.5, rely=0.45, anchor=tk.N)
        elif naive_bayes:
            # Button to show probability distribution plot
            probability_button = tk.Button(result_frame, text="Probability Distribution Plot", command=lambda: self.show_probability_distribution(model, X_test), bg="#007bff", fg="white", font=("Helvetica", 12))
            probability_button.place(relx=0.5, rely=0.45, anchor=tk.N)

        close_button = tk.Button(result_frame, text="Close", command=result_window.destroy, bg="#007bff", fg="white")
        close_button.place(relx=0.5, rely=0.95, anchor=tk.N)

    def show_confusion_matrix(self, y_test, y_pred):
        """
        Show the confusion matrix
        """
        cm = confusion_matrix(y_test, y_pred)

        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt="d")
        plt.title("Confusion Matrix")
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        plt.show()

    def show_classification_report(self, y_test, y_pred):
        """
        Show the classification report
        """
        report = classification_report(y_test, y_pred)
        report_window = tk.Toplevel(self.master)
        report_window.title("Classification Report")
        report_window.geometry("400x300")

        report_frame = tk.Frame(report_window, bg="#E8E8E8")
        report_frame.place(relwidth=1, relheight=1)

        report_label = tk.Label(report_frame, text="Classification Report", font=("Helvetica", 14, "bold"), bg="#E8E8E8")
        report_label.place(relx=0.5, rely=0.05, anchor=tk.N)

        report_text = tk.Text(report_frame, height=12, width=50)
        report_text.place(relx=0.5, rely=0.3, anchor=tk.N)
        report_text.insert(tk.END, report)

        close_button = tk.Button(report_frame, text="Close", command=report_window.destroy, bg="#007bff", fg="white")
        close_button.place(relx=0.5, rely=0.9, anchor=tk.N)

    def show_feature_importance(self, model, X_test):
        """
        Show the feature importance plot
        """
        feature_importance = model.coef_[0]
        sorted_idx = np.argsort(np.abs(feature_importance))
        pos = np.arange(sorted_idx.shape[0]) + .5

        plt.figure(figsize=(10, 6))
        plt.barh(pos, feature_importance[sorted_idx], align='center', color='#FF5733')
        plt.yticks(pos, np.array(X_test.columns)[sorted_idx])
        plt.xlabel('Feature Importance')
        plt.title('Feature Importance Plot')
        plt.show()

    def show_decision_tree(self, model, X_test):
        """
        Show the decision tree
        """
        plt.figure(figsize=(20,10))
        plot_tree(model, feature_names=X_test.columns, class_names=model.classes_, filled=True, rounded=True)
        plt.show()

    def show_scatter_plot(self, model, X_test):
        """
        Show the scatter plot
        """
        plt.figure(figsize=(10, 6))
        for class_label in np.unique(model.classes_):
            X_class = X_test[model.predict(X_test) == class_label]
            plt.scatter(X_class.iloc[:, 0], X_class.iloc[:, 1], label=f'Class {class_label}', alpha=0.7)
        plt.title("Scatter Plot of Data Points")
        plt.xlabel("Feature 1")
        plt.ylabel("Feature 2")
        plt.legend()
        plt.show()

    def show_probability_distribution(self, model, X_test):
        """
        Show the probability distribution plot
        """
        plt.figure(figsize=(10, 6))
        for class_label in np.unique(model.classes_):
            sns.kdeplot(X_test[model.predict(X_test) == class_label].iloc[:, 0], label=f'Class {class_label}', shade=True)
        plt.title("Probability Distribution Plot")
        plt.xlabel("Feature 1")
        plt.ylabel("Density")
        plt.legend()
        plt.show()

    def select_algorithm(self, dataset):
        """
        Function to display options and select an algorithm
        """
        algorithms = {
            "1": "Naive Bayes",
            "2": "Logistic Regression",
            "3": "Decision Tree (J48)",
            "4": "K-Nearest Neighbors (KNN)",
            "5": "Exit",
        }
        
        target_window = tk.Toplevel(self.master)
        target_window.title("Target Variable")
        target_window.geometry("300x150")

        target_frame = tk.Frame(target_window, bg="#E8E8E8")
        target_frame.place(relwidth=1, relheight=1)

        target_label = tk.Label(target_frame, text="Select the target variable:", font=("Helvetica", 12), bg="#E8E8E8")
        target_label.place(relx=0.5, rely=0.1, anchor=tk.N)

        target_options = dataset.columns
        target_variable = tk.StringVar(target_window)
        target_variable.set(target_options[0])

        target_dropdown = tk.OptionMenu(target_frame, target_variable, *target_options)
        target_dropdown.config(width=15)
        target_dropdown.place(relx=0.5, rely=0.3, anchor=tk.N)

        def on_target_submit():
            target = target_variable.get()
            target_window.destroy()
            if target.strip() == "":
                messagebox.showerror("Error", "Please enter a target variable.")
            else:
                algorithm_window = tk.Toplevel(self.master)
                algorithm_window.title("Select Algorithm")
                algorithm_window.geometry("400x350")

                algorithm_frame = tk.Frame(algorithm_window, bg="#E8E8E8")
                algorithm_frame.place(relwidth=1, relheight=1)

                algorithm_label = tk.Label(algorithm_frame, text="Select an Algorithm:", font=("Helvetica", 16, "bold"), bg="#E8E8E8")
                algorithm_label.place(relx=0.5, rely=0.2, anchor=tk.N)

                for i, (key, value) in enumerate(algorithms.items()):
                    algo_button = tk.Button(algorithm_frame, text=f"{value}", command=lambda v=value: self.on_algorithm_selected(dataset, target, v), bg="#007bff", fg="white", font=("Helvetica", 12))
                    algo_button.pack(pady=5)
                    algo_button.place(relx=0.5, rely=0.3 + i * 0.1, anchor=tk.N)

                cancel_button = tk.Button(algorithm_frame, text="Cancel", command=algorithm_window.destroy, bg="#007bff", fg="white", font=("Helvetica", 12))
                cancel_button.place(relx=0.5, rely=0.9, anchor=tk.N)

        target_submit_button = tk.Button(target_frame, text="Submit", command=on_target_submit, bg="#007bff", fg="white")
        target_submit_button.place(relx=0.5, rely=0.6, anchor=tk.N)

        target_cancel_button = tk.Button(target_frame, text="Cancel", command=target_window.destroy, bg="#007bff", fg="white")
        target_cancel_button.place(relx=0.5, rely=0.8, anchor=tk.N)

    def on_algorithm_selected(self, dataset, target, algorithm):
        """
        Function to run selected algorithm on dataset
        """
        features = [col for col in dataset.columns if col != target]

        if algorithm == "Naive Bayes":
            try:
                model = GaussianNB()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("Naive Bayes algorithm executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, naive_bayes=True)
            except ValueError:
                print("Naive Bayes does not support the dataset.")
        elif algorithm == "Logistic Regression":
            try:
                model = LogisticRegression()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("Logistic Regression algorithm executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, logistic=True)
            except ValueError:
                print("Logistic Regression does not support the dataset.")
        elif algorithm == "Decision Tree (J48)":
            try:
                model = DecisionTreeClassifier()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("Decision Tree algorithm (J48) executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, tree=True)
            except ValueError:
                print("Decision Tree does not support the dataset.")
        elif algorithm == "K-Nearest Neighbors (KNN)":
            try:
                model = KNeighborsClassifier()
                X_train, X_test, y_train, y_test = train_test_split(dataset[features], dataset[target], test_size=0.2, random_state=42)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                print("K-Nearest Neighbors (KNN) algorithm executed successfully.")
                self.show_results(y_test, y_pred, model, X_test, knn=True)
            except ValueError:
                print("K-Nearest Neighbors (KNN) does not support the dataset.")

root = tk.Tk()
app = WekaCloneApp(root)
root.mainloop()


