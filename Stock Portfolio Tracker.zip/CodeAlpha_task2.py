import requests

class Stock_Portfolio:
    def __init__(self, api_key):
        self.portfolio = {}
        self.api_key = api_key

    def add_stock(self, symbol, quantity):
        if symbol in self.portfolio:
            self.portfolio[symbol] += quantity
        else:
            self.portfolio[symbol] = quantity

    def remove_stock(self, symbol, quantity):
        if symbol in self.portfolio:
            if self.portfolio[symbol] > quantity:
                self.portfolio[symbol] -= quantity
            else:
                del self.portfolio[symbol]

    def track_portfolio_value(self):
        total_value = 0
        for symbol, quantity in self.portfolio.items():
            price = self.get_stock_price(symbol)
            if price is not None:
                total_value += price * quantity
                print(f"{symbol}: {quantity} shares - Current Price: ${price:.2f}")
        print(f"Total Portfolio Value: ${total_value:.2f}")

    def get_stock_price(self, symbol):
        url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey={self.api_key}"
        response = requests.get(url)
        data = response.json()
        try:
            price = float(data['Global Quote']['05. price'])
            return price
        except KeyError:
            print(f"Error: Unable to retrieve stock price for {symbol}. Please check the stock symbol and try again.")
            return None
        except ValueError:
            print(f"Error: Unable to convert stock price for {symbol} to float.")
            return None

def main():
    api_key = 'YOUR_ALPHA_VANTAGE_API_KEY'  # Replace with your API key
    portfolio = Stock_Portfolio(api_key)

    while True:
        print("\n1. Add Stock\n2. Remove Stock\n3. Track Portfolio Value\n4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            symbol = input("Enter stock symbol (USD, RS, INR, EUR, AUD, SAR): ").upper()
            quantity = int(input("Enter quantity: "))
            portfolio.add_stock(symbol, quantity)
            print(f"{quantity} shares of {symbol} added to the portfolio.")

        elif choice == '2':
            symbol = input("Enter stock symbol (USD, RS, INR, EUR, AUD, SAR): ").upper()
            quantity = int(input("Enter quantity: "))
            portfolio.remove_stock(symbol, quantity)
            print(f"{quantity} shares of {symbol} removed from the portfolio.")

        elif choice == '3':
            portfolio.track_portfolio_value()

        elif choice == '4':
            print("Exiting program.")
            break

        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
