import random
import nltk
from nltk.tokenize import word_tokenize

# Download NLTK data
nltk.download('punkt')

# Greetings
GREETING_INPUTS = ["hello", "hi", "hey", "greetings", "sup"]
GREETING_RESPONSES = ["Hi!", "Hey there!", "Hello!", "Greetings!", "Hey!", "Hi, how can I help you?"]

# Farewells
FAREWELL_INPUTS = ["bye", "goodbye", "see you", "see you later", "farewell"]
FAREWELL_RESPONSES = ["Goodbye!", "Bye!", "See you later!", "Have a great day!", "Take care!"]

# Responses for asking how the chatbot is doing
HOW_ARE_YOU_INPUTS = ["how are you", "how's it going", "how are you doing"]
HOW_ARE_YOU_RESPONSES = ["I'm doing well, thank you!", "I'm good, thanks for asking!", "I'm doing great!"]

# Responses for expressing gratitude
THANK_YOU_INPUTS = ["thank you", "thanks", "thanks a lot"]
THANK_YOU_RESPONSES = ["You're welcome!", "No problem!", "Anytime!"]

# Responses for specific user questions
SPECIFIC_RESPONSES = {
    "tell me something interesting.": "Here's a fun fact: The shortest war in history was between Britain and Zanzibar on August 27, 1896. Zanzibar surrendered after 38 minutes.",
    "what do you think about cats?": "Cats are fascinating creatures!",
    "do you have any hobbies?": "I enjoy programming and learning new things.",
    "have you heard about the amazing movie?": "Yeah, I would like to suggest you stranger things thats amazing.",
    "what's your opinion on technology?": "Technology is amazing and constantly evolving.",
    "can you share a fun fact?": "Sure! Here's an interesting fact:",
    "do you like pizza?": "Pizza is delicious! Who doesn't like pizza?"
}

def preprocess_input(sentence):
    """Tokenize and preprocess user input."""
    tokens = word_tokenize(sentence.lower())
    return tokens

def bot_response(user_input):
    """Generate a response for the user input."""
    
    # Check for specific user questions
    for question, response in SPECIFIC_RESPONSES.items():
        if question in user_input:
            return response
    
    # Check for greetings
    if any(word in user_input for word in GREETING_INPUTS):
        return random.choice(GREETING_RESPONSES)
    
    # Check for farewells
    if any(word in user_input for word in FAREWELL_INPUTS):
        return random.choice(FAREWELL_RESPONSES)
    
    # Check for asking how the chatbot is doing
    if any(word in user_input for word in HOW_ARE_YOU_INPUTS):
        return random.choice(HOW_ARE_YOU_RESPONSES)
    
    # Check for expressing gratitude
    if any(word in user_input for word in THANK_YOU_INPUTS):
        return random.choice(THANK_YOU_RESPONSES)
    
    # Default response
    return "I'm sorry, I don't understand that."

print("Bot: Hi, how can I assist you today?")

while True:
    user_input = input("You: ").strip()
    if user_input.lower() == 'exit':
        print("Bot: Goodbye!")
        break
    print("Bot:", bot_response(user_input))
